using Microsoft.EntityFrameworkCore;
using Pos.Local.Data;
using Pos.Local.Entities;

namespace Pos.Local.Services;

public static class LocalSeed
{
    public static async Task EnsureSeededAsync(PosLocalDbContext db, CancellationToken ct = default)
    {
        if (await db.Products.AnyAsync(ct)) return;

        db.Products.AddRange(
            new Product { Sku = "ITEM-001", Name = "Coca Cola 500ml", Price = 12.00m, Department = "Beverages" },
            new Product { Sku = "ITEM-002", Name = "Water 500ml", Price = 8.00m, Department = "Beverages" },
            new Product { Sku = "ITEM-003", Name = "Snack Pack", Price = 15.00m, Department = "Snacks" }
        );

        await db.SaveChangesAsync(ct);
    }
}
